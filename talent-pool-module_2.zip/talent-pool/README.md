# Talent Pool module — Eethal site

A self-contained module you can drop into the existing Eethal site.
Everything works standalone (open `login.html` in a browser) so you can
test it before wiring it into your real site and backend.

## Files

```
talent-pool/
  login.html            demo login page
  talent-pool.html       candidate listing (cards)
  candidate-detail.html  read-only profile view + export buttons
  candidate-form.html    add / edit candidate form (conditional fields)
  admin.html             admin-only consolidated table + export-all
  nav-snippet.html       the <li> to paste into your real header
  css/
    talent-pool.scss     source (Sass variables, mixins, nesting)
    talent-pool.css      pre-compiled, ready to use without a build step
  js/
    auth.js              login/session + nav visibility (demo, swap for real auth)
    store.js             candidate data (demo localStorage, swap for real API)
    export.js            Excel export (SheetJS) + SharePoint push (stub)
    ui.js                toast + avatar-initials helpers
    talent-pool.js        listing page logic
    candidate-form.js    add/edit form logic
    candidate-detail.js  detail view logic
    admin.js             admin dashboard logic
    login.js             login page logic
```

## How access works now

- **Visitors who are not logged in** see only an "Enroll now" panel on
  `talent-pool.html` — no candidate names, cards, or data of any kind.
  Clicking it opens `candidate-form.html`, a public enrollment form.
  On submit, the form itself shows a green checkmark confirmation
  ("Profile submitted") — it does not reveal any candidate list.
- **Admins**, once logged in, see the full `talent-pool.html` page
  instead: a searchable grid of every candidate, an "Add candidate"
  button, a delete icon on each card, and "Export to Excel" /
  "Push to SharePoint" buttons for the whole list.
- **Candidate detail view (`candidate-detail.html`)** is admin-only, and
  now also has a "Delete profile" button alongside Edit / Export /
  SharePoint.
- **Admin dashboard (`admin.html`)** is a secondary consolidated table
  view with the same export-all and delete actions, if you'd rather work
  from a table than a card grid.
- The nav bar shows a **Login** button when nobody is logged in, and
  swaps it for **Admin dashboard** + **Logout** once an admin signs in.

## Quick test

1. Open `talent-pool.html` directly — you'll see only the "Enroll now"
   panel, no candidate data.
2. Click "Enroll now", fill in the form, submit — a green checkmark
   confirms the profile was saved.
3. Go back to Talent Pool — still just the enroll panel (correct: you're
   not an admin).
4. Sign in via **Login** with `admin` / `admin123`.
5. Open Talent Pool again — now it's the full admin view: card grid,
   search, add/delete, and export-to-Excel / push-to-SharePoint buttons.
6. Click a card to open the full profile — Edit, Export, Push to
   SharePoint, and Delete are all there.

## Integrating into your real Eethal site

**1. Nav menu item**
Copy the markup from `nav-snippet.html` into your existing header's
`<nav>`, in the same row as your other menu items. "Talent Pool" is a
plain public link. `#nav-login` shows when nobody's logged in;
`#nav-admin-link` and `#nav-logout` show only once an admin signs in —
`js/auth.js` handles the toggling automatically. Add
`css/talent-pool.css` and `js/auth.js` to every page's `<head>`/`<body>`.

**2. Replace the demo login (`js/auth.js`)**
Right now, login is a hardcoded demo user list stored in `localStorage`.
Replace the body of `login()`, `logout()`, and `getSession()` with calls
to your real backend session/cookie/JWT check. Everything else in the
module only calls `TPAuth.isLoggedIn()`, `TPAuth.isAdmin()`, and
`TPAuth.getUser()` — so once you swap the implementation here, no other
file needs to change.

**3. Replace the demo data store (`js/store.js`)**
Candidates are stored in `localStorage` for now. Replace `getAll`,
`getById`, and `upsert` with `fetch()` calls to your real API, e.g.:
- `GET /api/candidates` → `getAll()`
- `GET /api/candidates/:id` → `getById(id)`
- `POST/PUT /api/candidates` → `upsert(candidate)`

**4. Wire up SharePoint (`js/export.js`)**
`pushToSharePoint()` is a stub. Set `SHAREPOINT_ENDPOINT` to a Power
Automate "When an HTTP request is received" flow (or your own backend
route) that writes rows into a SharePoint list or Excel file in a
document library. The function already POSTs `{ rows: [...] }` as JSON
— just point it at a real URL.

**5. Excel export**
Already fully working client-side via SheetJS
(`cdn.jsdelivr.net/npm/xlsx`). No backend needed — clicking "Export to
Excel" downloads an `.xlsx` file directly in the browser, for a single
candidate or, from the admin dashboard, everyone.

**6. Photo upload**
Currently stored as a base64 data URL in the candidate record (fine for
a demo/localStorage; not recommended for a real database — for
production, upload the file to your server/blob storage and store the
returned URL instead).

## Data fields implemented (per spec)

**Basic details (all candidates):** full name, mobile number, email ID,
current location/address, photo upload, candidate type (student /
working professional).

**Working professional:** total years of experience, current company,
current designation, current CTC, educational qualification.

**Student:** degree, specialization, year of graduation / pass-out year.

The form and detail view both show/hide the professional vs. student
section automatically based on the candidate type selected.
