/**
 * candidate-form.js — add/edit candidate form
 * Shows the Working Professional or Student fieldset depending on the
 * Candidate Type selected, per the spec.
 */
(function () {
  "use strict";

  var form = document.getElementById("tp-candidate-form");
  var typeSelect = document.getElementById("f-candidateType");
  var professionalSection = document.getElementById("section-professional");
  var studentSection = document.getElementById("section-student");
  var photoInput = document.getElementById("f-photo");
  var photoPreview = document.getElementById("photo-preview");
  var editId = new URLSearchParams(window.location.search).get("id");
  var photoDataUrl = "";

  function toggleSections() {
    var isStudent = typeSelect.value === "student";
    studentSection.classList.toggle("tp-active", isStudent);
    professionalSection.classList.toggle("tp-active", !isStudent);
  }

  function loadExisting() {
    if (!editId) return;

    if (!TPAuth.isAdmin()) {
      window.location.href = "login.html";
      return;
    }

    var c = TPStore.getById(editId);
    if (!c) return;

    form.fullName.value = c.fullName || "";
    form.mobile.value = c.mobile || "";
    form.email.value = c.email || "";
    form.location.value = c.location || "";
    typeSelect.value = c.candidateType || "professional";
    photoDataUrl = c.photo || "";
    if (photoDataUrl) photoPreview.src = photoDataUrl;

    if (c.professional) {
      form.experience.value = c.professional.experience || "";
      form.currentCompany.value = c.professional.currentCompany || "";
      form.designation.value = c.professional.designation || "";
      form.currentCTC.value = c.professional.currentCTC || "";
      form.education.value = c.professional.education || "";
    }
    if (c.student) {
      form.degree.value = c.student.degree || "";
      form.specialization.value = c.student.specialization || "";
      form.yearOfGraduation.value = c.student.yearOfGraduation || "";
    }

    toggleSections();
  }

  photoInput.addEventListener("change", function () {
    var file = photoInput.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      photoDataUrl = e.target.result;
      photoPreview.src = photoDataUrl;
    };
    reader.readAsDataURL(file);
  });

  typeSelect.addEventListener("change", toggleSections);

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var candidate = {
      id: editId || undefined,
      fullName: form.fullName.value.trim(),
      mobile: form.mobile.value.trim(),
      email: form.email.value.trim(),
      location: form.location.value.trim(),
      photo: photoDataUrl,
      candidateType: typeSelect.value,
      professional: typeSelect.value === "professional" ? {
        experience: form.experience.value.trim(),
        currentCompany: form.currentCompany.value.trim(),
        designation: form.designation.value.trim(),
        currentCTC: form.currentCTC.value.trim(),
        education: form.education.value.trim()
      } : null,
      student: typeSelect.value === "student" ? {
        degree: form.degree.value.trim(),
        specialization: form.specialization.value.trim(),
        yearOfGraduation: form.yearOfGraduation.value.trim()
      } : null
    };

    var saved = TPStore.upsert(candidate);
    var isEdit = !!editId;

    document.getElementById("tp-form-wrap").style.display = "none";
    document.getElementById("tp-success-title").textContent = isEdit ? "Profile updated" : "Profile submitted";
    document.getElementById("tp-success-message").textContent = isEdit
      ? saved.fullName + "'s details have been updated."
      : "Thanks, " + saved.fullName + "! Your profile has been saved. Our team will reach out if there's a match.";
    document.getElementById("tp-form-success").style.display = "";
  });

  document.addEventListener("DOMContentLoaded", function () {
    toggleSections();
    loadExisting();
  });
})();
