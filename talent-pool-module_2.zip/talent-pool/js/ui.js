/**
 * ui.js — Talent Pool module
 * Tiny shared UI helpers (toast messages, initials avatar).
 */
(function (window) {
  "use strict";

  function showToast(message) {
    var toast = document.getElementById("tp-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "tp-toast";
      toast.className = "tp-toast";
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add("tp-show");
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(function () {
      toast.classList.remove("tp-show");
    }, 2600);
  }

  function initials(name) {
    if (!name) return "?";
    var parts = name.trim().split(/\s+/);
    var first = parts[0] ? parts[0][0] : "";
    var last = parts.length > 1 ? parts[parts.length - 1][0] : "";
    return (first + last).toUpperCase();
  }

  window.TPUi = {
    showToast: showToast,
    initials: initials
  };
})(window);
