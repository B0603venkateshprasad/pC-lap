/**
 * login.js — demo login page
 */
(function () {
  "use strict";

  var form = document.getElementById("tp-login-form");
  var errorBox = document.getElementById("tp-login-error");

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var result = TPAuth.login(form.username.value.trim(), form.password.value);
    if (!result.ok) {
      errorBox.textContent = result.message;
      errorBox.style.display = "block";
      return;
    }
    window.location.href = result.session.isAdmin ? "admin.html" : "talent-pool.html";
  });
})();
