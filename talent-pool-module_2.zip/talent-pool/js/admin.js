/**
 * admin.js — admin-only consolidated view of all candidates
 */
(function () {
  "use strict";

  var tbody = document.getElementById("tp-admin-tbody");
  var countLabel = document.getElementById("tp-admin-count");

  function escapeHtml(str) {
    var div = document.createElement("div");
    div.textContent = str || "";
    return div.innerHTML;
  }

  function render() {
    var candidates = TPStore.getAll();
    countLabel.textContent = candidates.length + " candidate" + (candidates.length === 1 ? "" : "s");

    tbody.innerHTML = candidates.map(function (c) {
      var isStudent = c.candidateType === "student";
      return '<tr>' +
        '<td>' + escapeHtml(c.fullName) + '</td>' +
        '<td>' + escapeHtml(c.mobile) + '</td>' +
        '<td>' + escapeHtml(c.email) + '</td>' +
        '<td>' + escapeHtml(c.location) + '</td>' +
        '<td>' + (isStudent ? "Student" : "Working professional") + '</td>' +
        '<td>' + (isStudent ? escapeHtml(c.student && c.student.degree) : escapeHtml(c.professional && c.professional.currentCompany)) + '</td>' +
        '<td>' + (isStudent ? escapeHtml(c.student && c.student.yearOfGraduation) : escapeHtml(c.professional && c.professional.experience) + (c.professional ? " yrs" : "")) + '</td>' +
        '<td style="white-space:nowrap;">' +
        '<a class="tp-btn" href="candidate-detail.html?id=' + encodeURIComponent(c.id) + '">View</a> ' +
        '<button class="tp-btn-danger" data-id="' + escapeHtml(c.id) + '" data-name="' + escapeHtml(c.fullName) + '"><i class="ti ti-trash"></i></button>' +
        '</td>' +
        '</tr>';
    }).join("") || '<tr><td colspan="8" class="tp-empty">No candidates yet.</td></tr>';

    Array.prototype.forEach.call(tbody.querySelectorAll(".tp-btn-danger"), function (btn) {
      btn.addEventListener("click", function () {
        var id = btn.getAttribute("data-id");
        var name = btn.getAttribute("data-name");
        if (window.confirm("Delete " + name + "'s profile? This cannot be undone.")) {
          TPStore.remove(id);
          TPUi.showToast("Candidate deleted.");
          render();
        }
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    TPAuth.requireAdmin("login.html");
    render();

    document.getElementById("btn-export-all-excel").addEventListener("click", function () {
      TPExport.exportToExcel(TPStore.getAll(), "talent-pool-all-candidates.xlsx");
    });

    document.getElementById("btn-push-all-sharepoint").addEventListener("click", function () {
      TPExport.pushToSharePoint(TPStore.getAll()).then(function (result) {
        TPUi.showToast(result.message);
      });
    });
  });
})();
