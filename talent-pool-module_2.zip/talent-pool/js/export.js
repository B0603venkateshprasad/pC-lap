/**
 * export.js — Talent Pool module
 * -----------------------------------------------------------------------
 * Excel export uses SheetJS (loaded from CDN in each HTML page):
 *   <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
 *
 * SharePoint push is a STUB. To make it real, point SHAREPOINT_ENDPOINT
 * at a Power Automate "When an HTTP request is received" flow (or your
 * own backend route) that writes the rows into a SharePoint list /
 * document library. Nothing else in this file needs to change once
 * that endpoint exists.
 * -----------------------------------------------------------------------
 */
(function (window) {
  "use strict";

  // TODO: replace with your real Power Automate / backend endpoint.
  var SHAREPOINT_ENDPOINT = "";

  function flattenCandidate(c) {
    var row = {
      "Full Name": c.fullName || "",
      "Mobile Number": c.mobile || "",
      "Email ID": c.email || "",
      "Location": c.location || "",
      "Candidate Type": c.candidateType === "student" ? "Student" : "Working Professional"
    };

    if (c.candidateType === "professional" && c.professional) {
      row["Total Experience (yrs)"] = c.professional.experience || "";
      row["Current Company"] = c.professional.currentCompany || "";
      row["Current Designation"] = c.professional.designation || "";
      row["Current CTC"] = c.professional.currentCTC || "";
      row["Educational Qualification"] = c.professional.education || "";
    }

    if (c.candidateType === "student" && c.student) {
      row["Degree"] = c.student.degree || "";
      row["Specialization"] = c.student.specialization || "";
      row["Year of Graduation"] = c.student.yearOfGraduation || "";
    }

    return row;
  }

  // candidates: single candidate object OR array of candidates
  function exportToExcel(candidates, filename) {
    var list = Array.isArray(candidates) ? candidates : [candidates];
    var rows = list.map(flattenCandidate);

    if (typeof XLSX === "undefined") {
      console.error("SheetJS (xlsx) library not loaded. Add the CDN script tag before export.js.");
      return false;
    }

    var worksheet = XLSX.utils.json_to_sheet(rows);
    var workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Candidates");
    XLSX.writeFile(workbook, filename || "talent-pool-export.xlsx");
    return true;
  }

  // candidates: single candidate object OR array of candidates
  function pushToSharePoint(candidates) {
    var list = Array.isArray(candidates) ? candidates : [candidates];
    var rows = list.map(flattenCandidate);

    if (!SHAREPOINT_ENDPOINT) {
      console.warn("SharePoint endpoint not configured — set SHAREPOINT_ENDPOINT in export.js.");
      return Promise.resolve({ ok: false, message: "SharePoint endpoint not configured yet." });
    }

    return fetch(SHAREPOINT_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows: rows })
    })
      .then(function (res) {
        return { ok: res.ok, message: res.ok ? "Pushed to SharePoint." : "SharePoint push failed." };
      })
      .catch(function (err) {
        return { ok: false, message: "SharePoint push failed: " + err.message };
      });
  }

  window.TPExport = {
    exportToExcel: exportToExcel,
    pushToSharePoint: pushToSharePoint
  };
})(window);
