/**
 * auth.js — Talent Pool module
 * -----------------------------------------------------------------------
 * DEMO AUTH ONLY. This uses localStorage so the module works standalone.
 * Wire it to your real Eethal login system by replacing the three
 * functions below (login, logout, getSession) with calls to your actual
 * session/cookie/JWT logic. Every other file in this module only calls
 * TPAuth.isLoggedIn() / TPAuth.isAdmin() / TPAuth.getUser(), so once you
 * swap the implementation here, nothing else needs to change.
 * -----------------------------------------------------------------------
 */
(function (window) {
  "use strict";

  var SESSION_KEY = "tp_auth_session";

  // Demo user directory. Replace with a real API call in production.
  var DEMO_USERS = [
    { username: "admin", password: "admin123", name: "Admin User", isAdmin: true },
    { username: "user", password: "user123", name: "Recruiter", isAdmin: false }
  ];

  function getSession() {
    try {
      return JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    } catch (e) {
      return null;
    }
  }

  function login(username, password) {
    var match = DEMO_USERS.filter(function (u) {
      return u.username === username && u.password === password;
    })[0];

    if (!match) {
      return { ok: false, message: "Invalid username or password." };
    }

    var session = { name: match.name, username: match.username, isAdmin: match.isAdmin, loggedInAt: Date.now() };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    refreshNav();
    return { ok: true, session: session };
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    refreshNav();
  }

  function isLoggedIn() {
    return !!getSession();
  }

  function isAdmin() {
    var s = getSession();
    return !!(s && s.isAdmin);
  }

  function getUser() {
    return getSession();
  }

  // Toggles the nav bar controls on every page:
  //  #nav-login       — shown when nobody is logged in
  //  #nav-admin-link  — shown only when the logged-in user is an admin
  //  #nav-logout      — shown whenever someone is logged in
  // Call this on every page's load, and again right after login/logout.
  function refreshNav() {
    var loginBtn = document.getElementById("nav-login");
    var adminLink = document.getElementById("nav-admin-link");
    var logoutBtn = document.getElementById("nav-logout");
    var loggedIn = isLoggedIn();
    var admin = isAdmin();

    if (loginBtn) loginBtn.style.display = loggedIn ? "none" : "";
    if (adminLink) adminLink.style.display = admin ? "" : "none";
    if (logoutBtn) logoutBtn.style.display = loggedIn ? "" : "none";
  }

  // Guard for pages that require login (kept for any page you want to
  // lock to "logged in" without requiring admin specifically).
  function requireLogin(redirectTo) {
    if (!isLoggedIn()) {
      window.location.href = redirectTo || "login.html";
    }
  }

  // Guard for admin-only pages (candidate-detail.html, admin.html).
  function requireAdmin(redirectTo) {
    if (!isAdmin()) {
      window.location.href = redirectTo || "login.html";
    }
  }

  window.TPAuth = {
    login: login,
    logout: logout,
    isLoggedIn: isLoggedIn,
    isAdmin: isAdmin,
    getUser: getUser,
    refreshNav: refreshNav,
    requireLogin: requireLogin,
    requireAdmin: requireAdmin
  };

  document.addEventListener("DOMContentLoaded", refreshNav);
})(window);
