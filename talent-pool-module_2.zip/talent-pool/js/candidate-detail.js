/**
 * candidate-detail.js — read-only candidate profile view
 */
(function () {
  "use strict";

  var id = new URLSearchParams(window.location.search).get("id");
  var container = document.getElementById("tp-detail-root");

  function row(label, value) {
    return '<div class="tp-field"><label>' + label + '</label><div class="tp-view-value">' +
      (value ? escapeHtml(value) : "&mdash;") + '</div></div>';
  }

  function escapeHtml(str) {
    var div = document.createElement("div");
    div.textContent = str || "";
    return div.innerHTML;
  }

  function render() {
    var c = TPStore.getById(id);
    if (!c) {
      container.innerHTML = '<div class="tp-empty">Candidate not found. <a href="talent-pool.html">Back to Talent Pool</a></div>';
      return;
    }

    var avatarHtml = c.photo
      ? '<img class="tp-avatar" src="' + c.photo + '" alt="">'
      : '<div class="tp-avatar">' + TPUi.initials(c.fullName) + '</div>';

    var badgeClass = c.candidateType === "student" ? "tp-badge-student" : "tp-badge-professional";
    var badgeLabel = c.candidateType === "student" ? "Student" : "Working professional";

    var professionalHtml = "";
    if (c.candidateType === "professional" && c.professional) {
      professionalHtml =
        '<fieldset class="tp-fieldset"><legend>Working professional details</legend>' +
        '<div class="tp-field-grid">' +
        row("Total years of experience", c.professional.experience) +
        row("Current company", c.professional.currentCompany) +
        row("Current designation", c.professional.designation) +
        row("Current CTC", c.professional.currentCTC) +
        row("Educational qualification", c.professional.education) +
        '</div></fieldset>';
    }

    var studentHtml = "";
    if (c.candidateType === "student" && c.student) {
      studentHtml =
        '<fieldset class="tp-fieldset"><legend>Student details</legend>' +
        '<div class="tp-field-grid">' +
        row("Degree", c.student.degree) +
        row("Specialization", c.student.specialization) +
        row("Year of graduation / pass out year", c.student.yearOfGraduation) +
        '</div></fieldset>';
    }

    container.innerHTML =
      '<div class="tp-detail-card">' +
      '<div class="tp-detail-head">' + avatarHtml +
      '<div><div class="tp-detail-name">' + escapeHtml(c.fullName) + '</div>' +
      '<div class="tp-detail-sub">' + escapeHtml(c.mobile) + ' &middot; ' + escapeHtml(c.email) + '</div>' +
      '<span class="tp-badge ' + badgeClass + '">' + badgeLabel + '</span></div></div>' +

      '<fieldset class="tp-fieldset"><legend>Basic details</legend>' +
      '<div class="tp-field-grid">' +
      row("Full name", c.fullName) +
      row("Mobile number", c.mobile) +
      row("Email ID", c.email) +
      row("Current location / address", c.location) +
      row("Candidate type", badgeLabel) +
      '</div></fieldset>' +

      professionalHtml + studentHtml +

      '<div class="tp-actions-row">' +
      '<a class="tp-btn" href="candidate-form.html?id=' + encodeURIComponent(c.id) + '"><i class="ti ti-edit"></i>Edit</a>' +
      '<button class="tp-btn-accent" id="btn-export-excel"><i class="ti ti-file-spreadsheet"></i>Export to Excel</button>' +
      '<button class="tp-btn-primary" id="btn-push-sharepoint"><i class="ti ti-cloud-upload"></i>Push to SharePoint</button>' +
      '<button class="tp-btn-danger" id="btn-delete-candidate"><i class="ti ti-trash"></i>Delete profile</button>' +
      '</div></div>';

    document.getElementById("btn-delete-candidate").addEventListener("click", function () {
      if (window.confirm("Delete " + c.fullName + "'s profile? This cannot be undone.")) {
        TPStore.remove(c.id);
        sessionStorage.setItem("tp_toast_message", "Candidate deleted.");
        window.location.href = "talent-pool.html";
      }
    });

    document.getElementById("btn-export-excel").addEventListener("click", function () {
      TPExport.exportToExcel(c, c.fullName.replace(/\s+/g, "_") + "_profile.xlsx");
    });

    document.getElementById("btn-push-sharepoint").addEventListener("click", function () {
      TPExport.pushToSharePoint(c).then(function (result) {
        TPUi.showToast(result.message);
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    TPAuth.requireAdmin("login.html");
    render();
  });
})();
