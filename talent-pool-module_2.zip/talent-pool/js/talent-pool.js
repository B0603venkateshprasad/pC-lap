/**
 * talent-pool.js — renders the Talent Pool page.
 * Non-admins see only an "Enroll now" panel — no candidate data at all.
 * Admins see the full searchable grid with delete + export controls.
 */
(function () {
  "use strict";

  var publicPanel = document.getElementById("tp-public-panel");
  var adminPanel = document.getElementById("tp-admin-panel");
  var grid = document.getElementById("tp-grid");
  var searchInput = document.getElementById("tp-search");
  var typeFilter = document.getElementById("tp-type-filter");

  function escapeHtml(str) {
    var div = document.createElement("div");
    div.textContent = str || "";
    return div.innerHTML;
  }

  function render() {
    var query = (searchInput.value || "").toLowerCase().trim();
    var typeVal = typeFilter.value;

    var candidates = TPStore.getAll().filter(function (c) {
      var matchesQuery = !query ||
        (c.fullName && c.fullName.toLowerCase().indexOf(query) !== -1) ||
        (c.email && c.email.toLowerCase().indexOf(query) !== -1);
      var matchesType = typeVal === "all" || c.candidateType === typeVal;
      return matchesQuery && matchesType;
    });

    grid.innerHTML = "";

    if (candidates.length === 0) {
      grid.innerHTML = '<div class="tp-empty">No candidates found. Try a different search, or add a new candidate.</div>';
      return;
    }

    candidates.forEach(function (c) {
      var card = document.createElement("div");
      card.className = "tp-card";
      card.style.position = "relative";
      card.tabIndex = 0;
      card.setAttribute("role", "button");
      card.setAttribute("aria-label", "View profile of " + c.fullName);

      var badgeClass = c.candidateType === "student" ? "tp-badge-student" : "tp-badge-professional";
      var badgeLabel = c.candidateType === "student" ? "Student" : "Working professional";

      var avatarHtml = c.photo
        ? '<img class="tp-avatar" src="' + c.photo + '" alt="">'
        : '<div class="tp-avatar">' + TPUi.initials(c.fullName) + '</div>';

      card.innerHTML =
        '<button class="tp-card-delete" title="Delete profile" aria-label="Delete ' + escapeHtml(c.fullName) + '" ' +
        'style="position:absolute; top:8px; right:8px; background:transparent; border:none; color:#d64545; cursor:pointer; padding:4px;">' +
        '<i class="ti ti-trash" aria-hidden="true" style="font-size:16px;"></i></button>' +
        avatarHtml +
        '<div class="tp-card-name">' + escapeHtml(c.fullName) + '</div>' +
        '<div class="tp-card-meta">' + escapeHtml(c.mobile || "") + '</div>' +
        '<div class="tp-card-meta">' + escapeHtml(c.email || "") + '</div>' +
        '<div class="tp-card-meta">' + escapeHtml(c.location || "") + '</div>' +
        '<span class="tp-badge ' + badgeClass + '">' + badgeLabel + '</span>';

      card.addEventListener("click", function () {
        window.location.href = "candidate-detail.html?id=" + encodeURIComponent(c.id);
      });
      card.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          window.location.href = "candidate-detail.html?id=" + encodeURIComponent(c.id);
        }
      });

      card.querySelector(".tp-card-delete").addEventListener("click", function (e) {
        e.stopPropagation();
        if (window.confirm("Delete " + c.fullName + "'s profile? This cannot be undone.")) {
          TPStore.remove(c.id);
          TPUi.showToast("Candidate deleted.");
          render();
        }
      });

      grid.appendChild(card);
    });
  }

  function renderForRole() {
    if (TPAuth.isAdmin()) {
      publicPanel.style.display = "none";
      adminPanel.style.display = "";
      render();
    } else {
      adminPanel.style.display = "none";
      publicPanel.style.display = "";
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    renderForRole();

    if (searchInput) searchInput.addEventListener("input", render);
    if (typeFilter) typeFilter.addEventListener("change", render);

    var exportBtn = document.getElementById("btn-export-excel");
    var pushBtn = document.getElementById("btn-push-sharepoint");
    if (exportBtn) {
      exportBtn.addEventListener("click", function () {
        TPExport.exportToExcel(TPStore.getAll(), "talent-pool-all-candidates.xlsx");
      });
    }
    if (pushBtn) {
      pushBtn.addEventListener("click", function () {
        TPExport.pushToSharePoint(TPStore.getAll()).then(function (result) {
          TPUi.showToast(result.message);
        });
      });
    }

    var msg = sessionStorage.getItem("tp_toast_message");
    if (msg) {
      TPUi.showToast(msg);
      sessionStorage.removeItem("tp_toast_message");
    }
  });
})();
