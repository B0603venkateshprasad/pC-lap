/**
 * store.js — Talent Pool module
 * -----------------------------------------------------------------------
 * DEMO DATA LAYER ONLY. Backed by localStorage so the module works
 * without a server. Replace the body of each function with a fetch()
 * call to your real backend API (e.g. GET/POST /api/candidates) once
 * one exists — the function signatures are designed so nothing else in
 * this module needs to change.
 * -----------------------------------------------------------------------
 */
(function (window) {
  "use strict";

  var STORAGE_KEY = "tp_candidates";

  function seedIfEmpty() {
    var existing = localStorage.getItem(STORAGE_KEY);
    if (existing) return;

    var seed = [
      {
        id: "c1",
        fullName: "Arun Kumar",
        mobile: "9876543210",
        email: "arun.kumar@example.com",
        location: "Chennai, Tamil Nadu",
        photo: "",
        candidateType: "professional",
        professional: {
          experience: "5",
          currentCompany: "Acme Technologies",
          designation: "Senior Software Engineer",
          currentCTC: "12 LPA",
          education: "B.E. Computer Science"
        },
        student: null,
        createdAt: Date.now()
      },
      {
        id: "c2",
        fullName: "Priya Sharma",
        mobile: "9123456780",
        email: "priya.sharma@example.com",
        location: "Bengaluru, Karnataka",
        photo: "",
        candidateType: "student",
        professional: null,
        student: {
          degree: "B.Tech",
          specialization: "Information Technology",
          yearOfGraduation: "2026"
        },
        createdAt: Date.now()
      }
    ];

    localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
  }

  function getAll() {
    seedIfEmpty();
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    } catch (e) {
      return [];
    }
  }

  function getById(id) {
    return getAll().filter(function (c) { return c.id === id; })[0] || null;
  }

  function saveAll(list) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  }

  function upsert(candidate) {
    var list = getAll();
    if (!candidate.id) {
      candidate.id = "c" + Date.now();
      candidate.createdAt = Date.now();
      list.push(candidate);
    } else {
      list = list.map(function (c) {
        return c.id === candidate.id ? candidate : c;
      });
    }
    saveAll(list);
    return candidate;
  }

  function remove(id) {
    saveAll(getAll().filter(function (c) { return c.id !== id; }));
  }

  window.TPStore = {
    getAll: getAll,
    getById: getById,
    upsert: upsert,
    remove: remove
  };
})(window);
